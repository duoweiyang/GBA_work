
//{{BLOCK(pumpkin)

//======================================================================
//
//	pumpkin, 12x12@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 144 = 656
//
//	Time-stamp: 2018-10-11, 16:31:51
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PUMPKIN_H
#define GRIT_PUMPKIN_H

#define pumpkinBitmapLen 144
extern const unsigned short pumpkinBitmap[72];

#define pumpkinPalLen 512
extern const unsigned short pumpkinPal[256];

#endif // GRIT_PUMPKIN_H

//}}BLOCK(pumpkin)
