
//{{BLOCK(Pond)

//======================================================================
//
//	Pond, 240x160@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38400 = 38912
//
//	Time-stamp: 2018-10-16, 17:22:02
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_POND_H
#define GRIT_POND_H

#define PondBitmapLen 38400
extern const unsigned short PondBitmap[19200];

#define PondPalLen 512
extern const unsigned short PondPal[256];

#endif // GRIT_POND_H

//}}BLOCK(Pond)
